export default function App() {
  return (
    <div style={{
      background: "#000",
      color: "white",
      minHeight: "100vh",
      fontFamily: "Arial",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      textAlign: "center",
      padding: "40px"
    }}>
      <div>
        <h1 style={{fontSize:"70px", marginBottom:"20px"}}>SAAD BENINDALSI</h1>
        <p style={{fontSize:"24px", color:"#ccc"}}>
          Photographe • Filmmaker • Content Creator
        </p>

        <a
          href="https://www.instagram.com/castingat123?igsh=YmZyeTh4MGNyaGlm"
          target="_blank"
          style={{
            display:"inline-block",
            marginTop:"30px",
            padding:"16px 30px",
            background:"white",
            color:"black",
            borderRadius:"50px",
            textDecoration:"none",
            fontWeight:"bold"
          }}
        >
          Instagram
        </a>
      </div>
    </div>
  )
}
