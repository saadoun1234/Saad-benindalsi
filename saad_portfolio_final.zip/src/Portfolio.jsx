export default function SaadPortfolio() {
  return (
    <div style={{background:'black',color:'white',minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center',fontFamily:'Arial'}}>
      <div style={{textAlign:'center'}}>
        <h1 style={{fontSize:'80px'}}>SAAD BENINDALSI</h1>
        <p style={{fontSize:'24px'}}>Photographe • Filmmaker • Creative Director</p>

        <a
          href='https://www.instagram.com/castingat123?igsh=YmZyeTh4MGNyaGlm'
          target='_blank'
          style={{
            display:'inline-block',
            marginTop:'30px',
            padding:'16px 30px',
            background:'white',
            color:'black',
            borderRadius:'50px',
            textDecoration:'none',
            fontWeight:'bold'
          }}
        >
          Instagram
        </a>
      </div>
    </div>
  )
}
